# Media Stream AI — Complete Site (with IntuiTV)

Drop-in Next.js (App Router) project ready for GitHub + Netlify.

## Included
- New **/intuitv** page with channel logos ticker + merge animation, platforms, biometrics, FAQ.
- Home hero second button changed to **Explore IntuiTV**.
- Navigation: Solutions · Technology · Models · Robotics · VP Studio · Data Centre.
- Placeholders for any images not provided so you can see exactly what to replace.
- Fonts wired: Horizon (headlines) + Glacial Indifference (body).

## Replace these placeholders
- `/public/media/channels/*-placeholder.png`
- `/public/media/platforms/*-placeholder.svg`
- `/public/media/svg/*`
- `/public/media/mindmaps/*`
- `/public/media/*hero*.jpg`
- `/public/media/intuitv-logo-white.svg`
- `/public/fonts/*.woff2`

## Run locally
npm install
npm run dev

Then commit & push to GitHub; Netlify builds with `npm run build`.
