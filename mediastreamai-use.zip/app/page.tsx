"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";

export default function HomePage(){
  return (
    <div className="bg-black text-white">
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0">
          <Image src="/media/home-hero.jpg" alt="Media Stream AI – Smart TV, Made Personal" fill priority className="object-cover object-center opacity-90"/>
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/80" />
        </div>
        <div className="relative max-w-7xl mx-auto px-6 py-28 sm:py-36">
          <motion.h1 initial={{opacity:0,y:20}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.7}} className="font-horizon text-center text-5xl sm:text-6xl md:text-7xl leading-[1.05] tracking-tight">
            SMART TV, MADE PERSONAL
          </motion.h1>
          <motion.p initial={{opacity:0,y:16}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.6, delay:.1}} className="mt-6 text-center mx-auto max-w-2xl text-base sm:text-lg text-white/80 font-glacial">
            AI-powered TV experiences tailored to every viewer — informed by biometric and behavioral understanding.
          </motion.p>
          <motion.div initial={{opacity:0,y:14}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.6, delay:.2}} className="mt-8 flex items-center justify-center gap-3">
            <Link href="/vp-studio" className="btn btn-primary">Explore AI VP Studio</Link>
            <Link href="/intuitv" className="rounded-xl border border-white/20 bg-white/10 px-4 py-2 text-sm hover:bg-white/15 transition">Explore IntuiTV</Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
