/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        horizon: ["Horizon", "ui-sans-serif", "system-ui"],
        glacial: ["Glacial Indifference", "ui-sans-serif", "system-ui"],
      }
    },
  },
  plugins: [],
};
